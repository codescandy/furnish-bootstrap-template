
// Custom JS
document.addEventListener('DOMContentLoaded', () => {
  console.log('Bootstrap + Vite setup is ready!');
});
